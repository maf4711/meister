#!/bin/bash
# ==============================================================================
# meister2026.sh
#
# macOS Maintenance, Update & Self-Healing Script
# Version: 11.0
# Stand: 2026-03-08
#
# NEU in v11.0:
#   31. SICHERHEIT: eval durch /bin/bash -c ersetzt in safe_exec_lines
#   32. SICHERHEIT: Pipe/Chain-Blocker (;, &&, ||, |) in AI-Commands
#   33. SICHERHEIT: Config-Werte numerisch validiert
#   34. run_verbose: PIPESTATUS statt tmpfile Race-Condition
#   35. Trap-Vereinheitlichung: ein cleanup fuer INT/TERM/EXIT
#   36. Log-Rotation: 3 Generationen statt nur .old
#   37. -a Flag: Alle optionalen Module auf einmal
#   38. Exit-Code 1 bei Errors
#   39. ClamAV: Array statt eval fuer exclude_args
#   40. Magic Numbers als benannte Konstanten
#   41. Doppelter Ollama-Startcode in ensure_ollama_running() vereint
#   42. brew doctor Re-check nur nach tatsaechlichen Auto-Fixes
#   43. mas account Check vor Update
#   44. Sprache vereinheitlicht (Deutsch)
#   45. OLLAMA: Modell-Verfuegbarkeit pruefen + Auto-Pull/Fallback
#   46. OLLAMA: Konfigurierbarer Query-Timeout + Cold-Start-Erkennung
#   47. OLLAMA: Einmaliger Retry bei Query-Fehler
#   48. OLLAMA: Erweiterter Prompt mit macOS-/Chip-/Brew-Version
#   49. OLLAMA: Hash-basierter Query-Cache (gleiche Fehler nicht nochmal)
#   50. OLLAMA: Fehlerbehandlung in ollama_summary
#   51. OLLAMA: Query-Statistik (Anzahl, Dauer, Erfolge)
#   52. OLLAMA: qwen3-coder <think>-Tags rausfiltern
#
# NEU in v10.0:
#   22. brew doctor Auto-Fix (unlinked kegs, autoremove, Ollama-Fallback)
#   23. brew autoremove nach upgrade
#   24. MS Office: Sicherheitsrichtlinien-Check (MDM, MAU-Channel, TCC)
#   25. MS Office: Automatischer Retry nach Timeout
#   26. softwareupdate --install --recommended (auto-install)
#   27. Log-Analyse: Wiederkehrende Warnings erkennen
#   28. terminal-notifier mit Fallback auf osascript
#   29. Pushover-Benachrichtigung (optional via Config)
#   30. LaunchAgent Self-Setup (-I Flag)
#
# FIXES vs v9.0:
#   17. OLLAMA_MODEL Default auf llama3:latest (llama3.1:8b war nicht installiert)
#   18. ollama_query: Response-JSON mit tr bereinigen (Ollama liefert ungueltige
#       Control-Chars die jq/python3 crashen)
#   19. safe_exec_lines: AI-Response-Bereinigung (Markdown/Erklaerungen rausfiltern)
#   20. sudo-Whitelist erweitert: brew, mv, scutil hinzugefuegt
#   21. Blocklist-Regex: rm -rf / ohne Trailing-Char wird jetzt erkannt
#
# FIXES vs v8.0:
#   1.  eval durch safe_exec_lines ersetzt (Whitelist + Blocklist)
#   2.  Prompt-Injection-Schutz: sanitize_for_prompt()
#   3.  JSON-Building: jq bevorzugt, python3 mit argv statt stdin
#   4.  Pipe-Exit-Codes korrekt via run_verbose() Helper
#   5.  Subshell-Counter-Bug in module_ollama gefixt
#   6.  Stderr-Capture: Logfile-Diff statt leerer stderr-Datei
#   7.  Dead Code entfernt (RETRY_COUNT, RETRY_DELAY)
#   8.  Lockfile gegen parallele Instanzen
#   9.  Signal-Handling (trap) fuer sauberes Cleanup
#   10. Dry-Run-Modus (-n Flag)
#   11. Netzwerk-Check mit mehreren Endpunkten
#   12. brew --greedy statt --force
#   13. Config-Datei (~/.meister/config)
#   14. Logfile nach ~/.meister/meister.log verschoben
#   15. ClamAV: bessere Exclude-Patterns
#   16. Run-History in ~/.meister/history.log
#
# Usage: ./meister2026.sh [flags]
#   -a  ALLE optionalen Module    -A  ClamAV (sudo)
#   -X  Xcode clean               -M  Monolingual
#   -T  Trash leeren              -S  Sudo tasks
#   -C  Caches (sudo)             -L  Grosse Dateien
#   -O  LM Studio sync            -c  NUR ClamAV
#   -H  Health Dashboard          -n  Dry-Run
#   -I  LaunchAgent install       -h  Hilfe
# ==============================================================================

#############################
# 1. CONFIGURATION
#############################

MEISTER_DIR="$HOME/.meister"
mkdir -p "$MEISTER_DIR/patches" "$MEISTER_DIR/output" 2>/dev/null

# Defaults
LOGFILE="$MEISTER_DIR/meister.log"
LOCKFILE="$MEISTER_DIR/meister.lock"
MSUPDATE_PATH="/Library/Application Support/Microsoft/MAU2.0/Microsoft AutoUpdate.app/Contents/MacOS/msupdate"
DISK_USAGE_THRESHOLD=80
LARGE_FILE_SIZE_MB=1000
MSUPDATE_TIMEOUT=120
OLLAMA_URL="${OLLAMA_URL:-http://localhost:11434}"
OLLAMA_MODEL="${OLLAMA_MODEL:-qwen3-coder:30b}"
OLLAMA_FALLBACK_MODEL="llama3:latest"
OLLAMA_ENABLED=true
OLLAMA_QUERY_TIMEOUT=120
OLLAMA_QUERY_RETRIES=1
SELFHEAL_MAX_RETRIES=2
NET_CHECK_HOSTS="google.com apple.com cloudflare.com"
PUSHOVER_USER=""
PUSHOVER_TOKEN=""
REPORT_NOTIFY="local"
LAUNCHAGENT_SCHEDULE="weekly"

# Benannte Konstanten (Fix #40)
LOG_MAX_SIZE=1048576          # 1MB - Log-Rotation Schwelle
LOG_GENERATIONS=3             # Anzahl rotierter Logs
OLLAMA_STARTUP_WAIT=15        # Sekunden Warten auf Ollama-Server
LOG_CAPTURE_LINES=50          # Zeilen fuer Fehleranalyse aus Log
SAFE_CMD_MAX_LEN=500          # Max Laenge eines AI-Fix-Befehls
DISK_CRITICAL_THRESHOLD=95    # Prozent - Notfall-Cleanup Schwelle
OLLAMA_COLD_START_EXTRA=60    # Extra-Sekunden beim ersten Query (Modell-Load)

# Config-Datei laden (ueberschreibt Defaults)
MEISTER_CONFIG="$MEISTER_DIR/config"
if [ -f "$MEISTER_CONFIG" ]; then
    while IFS='=' read -r key value; do
        key=$(echo "$key" | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//')
        value=$(echo "$value" | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//')
        [ -z "$key" ] && continue
        [ "${key:0:1}" = "#" ] && continue
        # Fix #33: Numerische Werte validieren
        case "$key" in
            OLLAMA_MODEL)          OLLAMA_MODEL="$value" ;;
            OLLAMA_FALLBACK_MODEL) OLLAMA_FALLBACK_MODEL="$value" ;;
            OLLAMA_URL)            OLLAMA_URL="$value" ;;
            OLLAMA_QUERY_TIMEOUT)  [[ "$value" =~ ^[0-9]+$ ]] && OLLAMA_QUERY_TIMEOUT="$value" ;;
            OLLAMA_QUERY_RETRIES)  [[ "$value" =~ ^[0-9]+$ ]] && OLLAMA_QUERY_RETRIES="$value" ;;
            MSUPDATE_TIMEOUT)      [[ "$value" =~ ^[0-9]+$ ]] && MSUPDATE_TIMEOUT="$value" ;;
            DISK_USAGE_THRESHOLD)  [[ "$value" =~ ^[0-9]+$ ]] && DISK_USAGE_THRESHOLD="$value" ;;
            LARGE_FILE_SIZE_MB)    [[ "$value" =~ ^[0-9]+$ ]] && LARGE_FILE_SIZE_MB="$value" ;;
            SELFHEAL_MAX_RETRIES)  [[ "$value" =~ ^[0-9]+$ ]] && SELFHEAL_MAX_RETRIES="$value" ;;
            NET_CHECK_HOSTS)       NET_CHECK_HOSTS="$value" ;;
            PUSHOVER_USER)         PUSHOVER_USER="$value" ;;
            PUSHOVER_TOKEN)        PUSHOVER_TOKEN="$value" ;;
            REPORT_NOTIFY)         [[ "$value" =~ ^(local|pushover|all|none)$ ]] && REPORT_NOTIFY="$value" ;;
            LAUNCHAGENT_SCHEDULE)  [[ "$value" =~ ^(daily|weekly|monthly)$ ]] && LAUNCHAGENT_SCHEDULE="$value" ;;
        esac
    done < "$MEISTER_CONFIG"
fi

# Report Arrays
declare -a REPORT_SUCCESS
declare -a REPORT_FIXED
declare -a REPORT_WARNINGS
declare -a REPORT_ERRORS
declare -a REPORT_HEALED
MSUPDATE_OUTPUT_LOG=""
SCRIPT_START_TIME=$(date +%s)

# Fix #51: Ollama Query-Statistik (dateibasiert wg. Subshell-Problem)
OLLAMA_STATS_FILE="$MEISTER_DIR/output/ollama_stats_$$.dat"
OLLAMA_COLD_START=true
mkdir -p "$MEISTER_DIR/cache" 2>/dev/null
echo "0 0 0 0 0" > "$OLLAMA_STATS_FILE"

# Statistik-Helfer (atomar, Subshell-sicher)
ollama_stat_inc() {
    local field="$1" amount="${2:-1}"
    local counts
    read -r c_count c_ok c_fail c_cached c_secs < "$OLLAMA_STATS_FILE"
    case "$field" in
        count)  c_count=$((c_count + amount)) ;;
        ok)     c_ok=$((c_ok + amount)) ;;
        fail)   c_fail=$((c_fail + amount)) ;;
        cached) c_cached=$((c_cached + amount)) ;;
        secs)   c_secs=$((c_secs + amount)) ;;
    esac
    echo "$c_count $c_ok $c_fail $c_cached $c_secs" > "$OLLAMA_STATS_FILE"
}

ollama_stat_read() {
    cat "$OLLAMA_STATS_FILE" 2>/dev/null || echo "0 0 0 0 0"
}
MODULE_STEP=0
MODULE_TOTAL=0
SUDO_KEEPALIVE_PID=""
INTERRUPTED=false

# Flags
RUN_CLAMAV=false
CLEAN_XCODE=false
RUN_MONOLINGUAL=false
EMPTY_TRASH=false
RUN_SUDO_TASKS=false
CLEAN_CACHES=false
LIST_LARGE_FILES=false
RUN_LMSTUDIO_COPY=false
CLAMAV_ONLY=false
NEEDS_SUDO=false
SHOW_HEALTH=false
DRY_RUN=false
INSTALL_LAUNCHAGENT=false

#############################
# 2. CORE HELPERS & LOGGING
#############################

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

log() {
    local level="$1"; shift; local msg="$*"
    local ts=$(date +'%Y-%m-%d %H:%M:%S')
    local color=$NC
    case "$level" in
        INFO)  color=$GREEN ;;
        WARN)  color=$YELLOW ;;
        ERROR) color=$RED ;;
        FIX)   color=$CYAN ;;
        HEAL)  color=$MAGENTA ;;
        STEP)  color=$DIM ;;
    esac
    echo -e "${color}[${level}]${NC} ${msg}"
    echo "$ts - $level - $msg" | sed 's/\x1b\[[0-9;]*m//g' >> "$LOGFILE"
}

section_header() {
    local title="$1"
    MODULE_STEP=$((MODULE_STEP + 1))
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  [${MODULE_STEP}/${MODULE_TOTAL}] ${BOLD}${title}${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

module_timer_start() {
    MODULE_START_TS=$(date +%s)
}

module_timer_stop() {
    local name="$1"
    local end_ts=$(date +%s)
    local elapsed=$((end_ts - MODULE_START_TS))
    local mins=$((elapsed / 60))
    local secs=$((elapsed % 60))
    if [ $mins -gt 0 ]; then
        log STEP "   ${name} abgeschlossen in ${mins}m ${secs}s"
    else
        log STEP "   ${name} abgeschlossen in ${secs}s"
    fi
}

report_add() {
    local type="$1"; local msg="$2"
    case "$type" in
        SUCCESS) REPORT_SUCCESS+=("$msg") ;;
        FIX)     REPORT_FIXED+=("$msg") ;;
        WARN)    REPORT_WARNINGS+=("$msg") ;;
        ERROR)   REPORT_ERRORS+=("$msg") ;;
        HEALED)  REPORT_HEALED+=("$msg") ;;
    esac
}

command_exists() { command -v "$1" &> /dev/null; }

rotate_logs() {
    if [ -f "$LOGFILE" ]; then
        local size=$(stat -f%z "$LOGFILE" 2>/dev/null || echo 0)
        if [ "$size" -gt "$LOG_MAX_SIZE" ]; then
            # Fix #36: Nummerierte Rotation (3 Generationen)
            local i=$((LOG_GENERATIONS - 1))
            while [ $i -ge 1 ]; do
                [ -f "${LOGFILE}.$i" ] && mv "${LOGFILE}.$i" "${LOGFILE}.$((i + 1))"
                i=$((i - 1))
            done
            [ -f "${LOGFILE}.old" ] && mv "${LOGFILE}.old" "${LOGFILE}.1"
            mv "$LOGFILE" "${LOGFILE}.old"
            log INFO "Logfile rotiert (war $(( size / 1024 ))KB)"
        fi
    fi
    touch "$LOGFILE"
}

# Fuehrt Befehl aus, zeigt Output zeilenweise, gibt echten Exit-Code zurueck
# Fix #34: PIPESTATUS statt tmpfile (Race-Condition vermeiden)
run_verbose() {
    if $DRY_RUN; then
        log STEP "   [DRY-RUN] $*"
        return 0
    fi
    "$@" 2>&1 | while IFS= read -r line; do
        [ -n "$line" ] && log STEP "   $line"
    done
    return ${PIPESTATUS[0]}
}

# Einfacher Dry-Run-Wrapper ohne Output-Streaming
run_or_dry() {
    if $DRY_RUN; then
        log STEP "   [DRY-RUN] $*"
        return 0
    fi
    "$@"
}

# Fix #8: Lockfile
acquire_lock() {
    if [ -f "$LOCKFILE" ]; then
        local old_pid=$(cat "$LOCKFILE" 2>/dev/null)
        if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
            log ERROR "Meister laeuft bereits (PID: $old_pid)"
            exit 1
        else
            log WARN "Stale Lockfile entfernt (PID $old_pid nicht mehr aktiv)"
            rm -f "$LOCKFILE"
        fi
    fi
    echo $$ > "$LOCKFILE"
}

release_lock() {
    rm -f "$LOCKFILE" 2>/dev/null
}

# Fix #35: Vereinheitlichter Trap fuer INT/TERM/EXIT
cleanup() {
    if $INTERRUPTED; then return; fi
    INTERRUPTED=true
    # Bei Signal (nicht normalem Exit) Report ausgeben
    if [ -n "$CLEANUP_SIGNAL" ]; then
        echo ""
        log WARN "Script unterbrochen ($CLEANUP_SIGNAL), raeume auf..."
        print_report 2>/dev/null
        save_history 2>/dev/null
    fi
    [ -n "$SUDO_KEEPALIVE_PID" ] && kill "$SUDO_KEEPALIVE_PID" 2>/dev/null
    rm -f "$MEISTER_DIR/output"/*_$$.log "$OLLAMA_STATS_FILE" 2>/dev/null
    release_lock
}

trap 'CLEANUP_SIGNAL=INT; cleanup' INT
trap 'CLEANUP_SIGNAL=TERM; cleanup' TERM
trap 'cleanup' EXIT

#############################
# 3. OLLAMA SELF-HEALING
#############################

ollama_available() {
    [ "$OLLAMA_ENABLED" = "true" ] && curl -sf --max-time 5 "${OLLAMA_URL}/api/tags" >/dev/null 2>&1
}

# Fix #41: Zentraler Ollama-Starter (ersetzt doppelten Code in module_ollama + main)
ensure_ollama_running() {
    local context="${1:-}"  # optionaler Kontext fuer Log-Meldungen
    if ollama_available; then
        return 0
    fi
    if ! command_exists ollama; then
        return 1
    fi
    log WARN "${context}Ollama offline - starte Server..."
    ollama serve &>/dev/null &
    local ollama_pid=$!
    local wait_count=0
    while [ $wait_count -lt "$OLLAMA_STARTUP_WAIT" ]; do
        sleep 1
        wait_count=$((wait_count + 1))
        if curl -sf --max-time 2 "${OLLAMA_URL}/api/tags" >/dev/null 2>&1; then
            break
        fi
        [ $((wait_count % 5)) -eq 0 ] && log STEP "${context}   Warte auf Ollama-Server... (${wait_count}s)"
    done
    if ollama_available; then
        log FIX "${context}Ollama-Server gestartet (nach ${wait_count}s)"
        OLLAMA_ENABLED=true
        return 0
    else
        log WARN "${context}Ollama-Server antwortet nicht nach ${OLLAMA_STARTUP_WAIT}s"
        if kill -0 "$ollama_pid" 2>/dev/null; then
            log STEP "${context}   Prozess laeuft (PID: $ollama_pid) aber API nicht erreichbar"
        else
            log WARN "${context}   Ollama-Prozess sofort beendet"
            local ollama_log="$HOME/.ollama/logs/server.log"
            if [ -f "$ollama_log" ]; then
                log STEP "${context}   Letzte Logzeilen:"
                tail -5 "$ollama_log" 2>/dev/null | while IFS= read -r line; do
                    log STEP "${context}     $line"
                done
            fi
        fi
        OLLAMA_ENABLED=false
        return 1
    fi
}

# Fix #45: Modell-Verfuegbarkeit pruefen, Auto-Pull oder Fallback
ensure_ollama_model() {
    if ! ollama_available; then return 1; fi
    local model="$OLLAMA_MODEL"
    # Modellname ohne Tag fuer grep (z.B. "qwen3-coder" aus "qwen3-coder:30b")
    if ollama list 2>/dev/null | awk 'NR>1 {print $1}' | grep -q "^${model}$"; then
        log STEP "   Modell $model verfuegbar"
        return 0
    fi
    # Modell nicht vorhanden - versuche Auto-Pull
    log WARN "   Modell $model nicht lokal verfuegbar, starte Pull..."
    if ollama pull "$model" 2>/dev/null; then
        log FIX "   Modell $model erfolgreich heruntergeladen"
        report_add FIX "Ollama: Modell $model auto-pulled"
        return 0
    fi
    # Pull fehlgeschlagen - Fallback-Modell pruefen
    if [ -n "$OLLAMA_FALLBACK_MODEL" ] && [ "$OLLAMA_FALLBACK_MODEL" != "$model" ]; then
        if ollama list 2>/dev/null | awk 'NR>1 {print $1}' | grep -q "^${OLLAMA_FALLBACK_MODEL}$"; then
            log WARN "   Fallback auf $OLLAMA_FALLBACK_MODEL (statt $model)"
            OLLAMA_MODEL="$OLLAMA_FALLBACK_MODEL"
            report_add WARN "Ollama: Fallback auf $OLLAMA_FALLBACK_MODEL"
            return 0
        fi
    fi
    # Letzter Versuch: erstes verfuegbares Modell nehmen
    local first_model=$(ollama list 2>/dev/null | awk 'NR==2 {print $1}')
    if [ -n "$first_model" ]; then
        log WARN "   Fallback auf erstes verfuegbares Modell: $first_model"
        OLLAMA_MODEL="$first_model"
        report_add WARN "Ollama: Fallback auf $first_model"
        return 0
    fi
    log ERROR "   Kein Ollama-Modell verfuegbar"
    OLLAMA_ENABLED=false
    return 1
}

# Fix #2: Prompt-Injection-Schutz
sanitize_for_prompt() {
    local input="$1"
    local max_len="${2:-1000}"
    # Kontrollzeichen entfernen, Laenge begrenzen, gefaehrliche Shell-Zeichen strippen
    echo "$input" | tr -cd '[:print:]\n' | head -c "$max_len" | sed 's/[`]//g'
}

# Fix #52: qwen3-coder <think>-Tags entfernen
strip_think_tags() {
    # Entfernt <think>...</think> Bloecke (auch mehrzeilig)
    sed '/<think>/,/<\/think>/d' | sed 's/<think>[^<]*<\/think>//g'
}

# Fix #49: Hash-basierter Query-Cache
ollama_cache_key() {
    local prompt="$1"
    # MD5-Hash des Prompts als Cache-Key
    echo "$prompt" | md5 2>/dev/null || echo "$prompt" | md5sum 2>/dev/null | awk '{print $1}'
}

ollama_cache_get() {
    local hash="$1"
    local cache_file="$MEISTER_DIR/cache/${hash}"
    # Cache gueltig fuer 24 Stunden
    if [ -f "$cache_file" ]; then
        local cache_age=$(( $(date +%s) - $(stat -f%m "$cache_file" 2>/dev/null || echo 0) ))
        if [ "$cache_age" -lt 86400 ]; then
            cat "$cache_file"
            return 0
        fi
        rm -f "$cache_file"
    fi
    return 1
}

ollama_cache_set() {
    local hash="$1"
    local response="$2"
    echo "$response" > "$MEISTER_DIR/cache/${hash}" 2>/dev/null
}

# Interner Query ohne Retry/Cache/Stats (wird von ollama_query aufgerufen)
_ollama_raw_query() {
    local prompt="$1"
    local timeout="$2"
    local json_payload

    if command_exists jq; then
        json_payload=$(jq -n \
            --arg model "$OLLAMA_MODEL" \
            --arg prompt "$prompt" \
            '{model: $model, prompt: $prompt, stream: false, options: {temperature: 0.1, num_predict: 512}}')
    elif command_exists python3; then
        json_payload=$(python3 -c "
import sys, json
print(json.dumps({
    'model': sys.argv[1],
    'prompt': sys.stdin.read(),
    'stream': False,
    'options': {'temperature': 0.1, 'num_predict': 512}
}))" "$OLLAMA_MODEL" <<< "$prompt" 2>/dev/null)
    else
        log WARN "Kein jq oder python3 fuer JSON-Encoding verfuegbar"
        return 1
    fi

    [ -z "$json_payload" ] && return 1

    local response
    response=$(curl -sf --max-time "$timeout" "${OLLAMA_URL}/api/generate" \
        -H "Content-Type: application/json" \
        -d "$json_payload" 2>/dev/null)

    [ $? -ne 0 ] || [ -z "$response" ] && return 1

    # Fix #18: Ollama JSON-Bereinigung + Fix #52: think-Tags entfernen
    local parsed
    if command_exists jq; then
        parsed=$(echo "$response" | awk '{if(NR>1) printf "\\n"; printf "%s", $0}' | jq -r '.response // ""')
    else
        parsed=$(echo "$response" | awk '{if(NR>1) printf "\\n"; printf "%s", $0}' | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('response',''))" 2>/dev/null)
    fi

    # Fix #52: <think>-Tags rausfiltern (qwen3-coder)
    echo "$parsed" | strip_think_tags
}

# Fix #46/#47/#49/#51: Ollama Query mit Timeout, Retry, Cache und Statistik
ollama_query() {
    local prompt="$1"
    local use_cache="${2:-true}"
    ollama_stat_inc count

    # Fix #49: Cache pruefen
    if [ "$use_cache" = "true" ]; then
        local cache_hash=$(ollama_cache_key "$prompt")
        local cached_result
        if cached_result=$(ollama_cache_get "$cache_hash"); then
            ollama_stat_inc cached
            ollama_stat_inc ok
            log STEP "   (Cache-Hit)" >&2
            echo "$cached_result"
            return 0
        fi
    fi

    # Fix #46: Timeout berechnen (Cold-Start beruecksichtigen)
    local timeout="$OLLAMA_QUERY_TIMEOUT"
    if $OLLAMA_COLD_START; then
        timeout=$((timeout + OLLAMA_COLD_START_EXTRA))
        log STEP "   Cold-Start: Timeout ${timeout}s (normal: ${OLLAMA_QUERY_TIMEOUT}s)" >&2
    fi

    local query_start=$(date +%s)
    local result

    # Erster Versuch
    result=$(_ollama_raw_query "$prompt" "$timeout")
    local rc=$?

    # Fix #47: Retry bei Fehler
    if [ $rc -ne 0 ] && [ "$OLLAMA_QUERY_RETRIES" -gt 0 ]; then
        log WARN "   Ollama-Query fehlgeschlagen, Retry..." >&2
        sleep 2
        result=$(_ollama_raw_query "$prompt" "$timeout")
        rc=$?
    fi

    local query_end=$(date +%s)
    local query_dur=$((query_end - query_start))
    ollama_stat_inc secs "$query_dur"

    # Nach erstem erfolgreichen Query: Cold-Start abschalten
    if [ $rc -eq 0 ] && [ -n "$result" ]; then
        OLLAMA_COLD_START=false
        ollama_stat_inc ok

        # Cache speichern
        if [ "$use_cache" = "true" ]; then
            ollama_cache_set "$cache_hash" "$result"
        fi

        echo "$result"
        return 0
    fi

    ollama_stat_inc fail
    log WARN "   Ollama-Query endgueltig fehlgeschlagen (${query_dur}s)" >&2
    return 1
}

# Fix #48: System-Info fuer bessere Prompts sammeln
get_system_context() {
    local macos_ver=$(sw_vers -productVersion 2>/dev/null || echo "unbekannt")
    local chip=$(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo "unbekannt")
    local brew_ver=$(brew --version 2>/dev/null | head -1 || echo "unbekannt")
    local bash_ver=$(/bin/bash --version 2>/dev/null | head -1 | sed 's/.*version //' | sed 's/ .*//')
    echo "SYSTEM: macOS ${macos_ver}, ${chip}, Homebrew ${brew_ver}, Bash ${bash_ver}"
}

selfheal_analyze() {
    local module_name="$1"
    local error_output="$2"
    local exit_code="$3"

    # Fix #2: Fehlertext sanitizen
    local safe_error=$(sanitize_for_prompt "$error_output" 800)

    # Fix #48: Erweiterte System-Info
    local sys_ctx=$(get_system_context)

    local prompt="Du bist ein macOS System-Administrator. Ein Wartungsscript-Modul ist fehlgeschlagen.

MODUL: ${module_name}
EXIT CODE: ${exit_code}
FEHLER:
${safe_error}

${sys_ctx}

Liefere NUR den Fix-Befehl (Shell-Commands, eine pro Zeile).
Keine Erklaerungen. Kein Markdown. Keine <think>-Tags. Muss ohne Interaktion laufen.
Erlaubte Befehle: brew, git, sudo, xcode-select, dscacheutil, killall, rm, mkdir, cp, mv, defaults, softwareupdate, mas, ollama.
Wenn kein Fix moeglich: nur NOFIX"

    ollama_query "$prompt"
}

# Fix #31: /bin/bash -c statt eval, Fix #32: Pipe/Chain-Blocker
safe_exec_lines() {
    local fix_cmd="$1"
    local module_name="$2"
    local blocked=false
    local tmpscript=$(mktemp)
    local rc=0

    # Zeile fuer Zeile validieren
    while IFS= read -r line; do
        local stripped=$(echo "$line" | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//')
        [ -z "$stripped" ] && continue
        [ "${stripped:0:1}" = "#" ] && continue
        # Fix #19: AI-Response-Bereinigung - Markdown und Erklaerungen rausfiltern
        echo "$stripped" | grep -qiE '^(```|here |the |this |note:|warning:|these )' && continue
        # Nummern-Praefixe entfernen (Ollama liefert "1. sudo rm ...")
        stripped=$(echo "$stripped" | sed -E 's/^[0-9]+\.[[:space:]]*//')
        [ -z "$stripped" ] && continue

        # Laengen-Check
        if [ ${#stripped} -gt "$SAFE_CMD_MAX_LEN" ]; then
            log ERROR "BLOCKED: Zeile zu lang (${#stripped} Zeichen)"
            blocked=true
            break
        fi

        # Fix #32: Pipe/Chain-Blocker - keine verketteten Befehle
        if echo "$stripped" | grep -qE '[;|&]{1,2}'; then
            log ERROR "BLOCKED: Pipe/Chain in Befehl: $stripped"
            blocked=true
            break
        fi

        # Erweiterte Blocklist (Patterns)
        if echo "$stripped" | grep -qiE \
            'rm -rf /($|[^A-Za-z~.])|mkfs|dd if=|chmod -R 777 /|> /dev/|eval |exec [^-]|base64|curl.*sh|wget.*sh|python.*-c.*import os|osascript.*-e.*do shell|launchctl.*remove|diskutil.*erase|nvram'; then
            log ERROR "BLOCKED: Gefaehrliches Pattern: $stripped"
            blocked=true
            break
        fi

        # Whitelist: erster Befehl muss erlaubt sein
        local first_word=$(echo "$stripped" | awk '{print $1}')
        case "$first_word" in
            brew|git|sudo|xcode-select|dscacheutil|killall|rm|mkdir|cp|mv|defaults|softwareupdate|mas|ollama|mdimport|periodic|sleep|true)
                # Erlaubt
                ;;
            *)
                log ERROR "BLOCKED: '$first_word' nicht in Whitelist"
                blocked=true
                break
                ;;
        esac

        # sudo-Subcommand pruefen
        if [ "$first_word" = "sudo" ]; then
            local sudo_cmd=$(echo "$stripped" | awk '{print $2}')
            case "$sudo_cmd" in
                dscacheutil|killall|periodic|xcode-select|softwareupdate|cp|mkdir|sed|rm|defaults|brew|mv|scutil|chmod|chown)
                    # Erlaubte sudo-Commands
                    ;;
                *)
                    log ERROR "BLOCKED: 'sudo $sudo_cmd' nicht erlaubt"
                    blocked=true
                    break
                    ;;
            esac
        fi

        # rm Validierung: nur bestimmte Pfade
        if [ "$first_word" = "rm" ] || echo "$stripped" | grep -q "sudo rm"; then
            if ! echo "$stripped" | grep -qE '(Library/Caches|\.Trash|DerivedData|/tmp/|/private/var/tmp|\.meister/)'; then
                log ERROR "BLOCKED: rm auf unerlaubtem Pfad: $stripped"
                blocked=true
                break
            fi
        fi

        echo "$stripped" >> "$tmpscript"
    done <<< "$fix_cmd"

    if $blocked; then
        rm -f "$tmpscript"
        report_add ERROR "AI-Fix geblockt (Sicherheit): $module_name"
        return 1
    fi

    # Fix #31: Validierte Zeilen via /bin/bash -c ausfuehren (kein eval)
    while IFS= read -r cmd; do
        [ -z "$cmd" ] && continue
        log STEP "   Exec: $cmd"
        /bin/bash -c "$cmd" 2>&1
        rc=$?
        if [ $rc -ne 0 ]; then
            log WARN "   Befehl Exit: $rc"
        fi
    done < "$tmpscript"

    rm -f "$tmpscript"
    return $rc
}

selfheal_apply() {
    local module_name="$1"
    local fix_cmd="$2"

    # Patch archivieren
    local ts=$(date +%Y%m%d_%H%M%S)
    echo "# AI-Fix: $module_name ($ts)" > "$MEISTER_DIR/patches/${module_name}_${ts}.sh"
    echo "$fix_cmd" >> "$MEISTER_DIR/patches/${module_name}_${ts}.sh"

    log HEAL "Wende AI-Fix an fuer $module_name..."

    # Fix #1: safe_exec_lines statt eval
    safe_exec_lines "$fix_cmd" "$module_name"
}

# Known-Fix Patterns: schnelle Fixes ohne Ollama
known_fix() {
    local module_name="$1"
    local error_output="$2"

    case "$error_output" in
        *"Could not resolve host"*|*"Failed to connect"*|*"Network is unreachable"*)
            log HEAL "Known-Fix: DNS/Netzwerk-Reset..."
            sudo dscacheutil -flushcache 2>/dev/null
            sudo killall -HUP mDNSResponder 2>/dev/null
            sleep 2
            return 0
            ;;
        *"No space left on device"*)
            log HEAL "Known-Fix: Platz schaffen..."
            rm -rf "$HOME/Library/Caches"/* 2>/dev/null
            brew cleanup -s 2>/dev/null
            return 0
            ;;
        *"shallow"*|*"fetch-pack"*|*"Could not resolve HEAD"*)
            log HEAL "Known-Fix: Homebrew Repo reparieren..."
            git -C "$(brew --repo)" fetch --unshallow 2>/dev/null
            brew update-reset 2>/dev/null
            return 0
            ;;
        *"already installed"*|*"is already an installed"*)
            log HEAL "Known-Fix: Bereits installiert, OK"
            return 0
            ;;
        *"Couldn't find remote ref"*|*"fatal: bad object"*)
            log HEAL "Known-Fix: Git-Repository Reset..."
            brew update-reset 2>/dev/null
            return 0
            ;;
        *"Error: Your CLT"*|*"xcode-select"*)
            log HEAL "Known-Fix: Xcode CLT reparieren..."
            sudo xcode-select --reset 2>/dev/null
            return 0
            ;;
        *"SIGTERM"*|*"Terminated"*|*"kill"*)
            log HEAL "Known-Fix: Prozess wurde beendet, Retry..."
            sleep 3
            return 0
            ;;
    esac
    return 1
}

# Fix #6: Logfile-Diff statt leerer stderr-Datei
run_module_safe() {
    local module_name="$1"
    local module_func="$2"
    local attempt=0
    local max=$((SELFHEAL_MAX_RETRIES + 1))

    section_header "$module_name"
    module_timer_start

    while [ $attempt -lt $max ]; do
        attempt=$((attempt + 1))
        [ $attempt -gt 1 ] && log HEAL "Retry ${attempt}/${max} fuer $module_name..."

        # Log-Position merken fuer Fehleranalyse
        local log_lines_before=$(wc -l < "$LOGFILE" 2>/dev/null || echo 0)

        $module_func
        local rc=$?

        if [ $rc -eq 0 ]; then
            [ $attempt -gt 1 ] && report_add HEALED "$module_name nach ${attempt} Versuchen geheilt"
            module_timer_stop "$module_name"
            return 0
        fi

        # Modul-Output aus Logfile extrahieren
        local module_output=$(tail -n +$((log_lines_before + 1)) "$LOGFILE" 2>/dev/null | head -"$LOG_CAPTURE_LINES")

        log ERROR "$module_name fehlgeschlagen (Exit: $rc)"

        if [ $attempt -ge $max ]; then
            report_add ERROR "$module_name nach ${max} Versuchen fehlgeschlagen"
            module_timer_stop "$module_name"
            return $rc
        fi

        # Erst Known-Fixes probieren
        local full_error="Exit: $rc. $module_output"
        if known_fix "$module_name" "$full_error"; then
            log HEAL "Known-Fix angewendet, neuer Versuch..."
            report_add HEALED "$module_name: Known-Fix angewendet"
            sleep 1
            continue
        fi

        # Dann Ollama
        if ! ollama_available; then
            log WARN "Ollama nicht erreichbar, kein AI-Fix moeglich"
            report_add ERROR "$module_name fehlgeschlagen (kein Ollama)"
            module_timer_stop "$module_name"
            return $rc
        fi

        log HEAL "Analysiere via Ollama (${OLLAMA_MODEL})..."
        local fix
        fix=$(selfheal_analyze "$module_name" "$full_error" "$rc")

        if [ -z "$fix" ] || [ "$fix" = "NOFIX" ]; then
            log WARN "Kein AI-Fix verfuegbar fuer $module_name"
            report_add WARN "Self-Heal: Kein Fix fuer $module_name"
            module_timer_stop "$module_name"
            return $rc
        fi

        log HEAL "Ollama schlaegt vor:"
        echo "$fix" | while IFS= read -r line; do
            [ -n "$line" ] && log STEP "   > $line"
        done

        selfheal_apply "$module_name" "$fix" || {
            report_add ERROR "AI-Fix fehlgeschlagen fuer $module_name"
            module_timer_stop "$module_name"
            return $rc
        }

        sleep 2
    done
}

#############################
# 4. INFRASTRUCTURE
#############################

# Fix #11: Mehrere Endpunkte
check_net() {
    log INFO "Pruefe Netzwerk..."
    for host in $NET_CHECK_HOSTS; do
        log STEP "   Teste $host..."
        if ping -c 1 -W 3 "$host" &>/dev/null; then
            log INFO "   Netzwerk OK (ping $host)"
            return 0
        fi
    done

    log STEP "   Ping fehlgeschlagen, versuche HTTPS..."
    for host in $NET_CHECK_HOSTS; do
        if curl -sf --max-time 5 "https://$host" >/dev/null 2>&1; then
            log INFO "   Netzwerk OK (HTTPS $host)"
            return 0
        fi
    done

    log ERROR "Keine Internet-Verbindung!"

    # Self-Healing: Netzwerk-Diagnose mit Ollama
    if ollama_available; then
        local net_info="DNS: $(scutil --dns 2>/dev/null | head -5)
Interface: $(ifconfig en0 2>/dev/null | grep 'inet ')
Route: $(netstat -rn 2>/dev/null | head -8)"
        log HEAL "Netzwerk-Diagnose via Ollama..."
        local diag
        diag=$(ollama_query "macOS hat keine Internetverbindung. Analysiere und gib Fix-Befehle:
$(sanitize_for_prompt "$net_info" 500)
Nur Shell-Commands, eine pro Zeile. Keine Erklaerungen, kein Markdown, keine <think>-Tags.
Erlaubt: sudo dscacheutil, sudo killall, defaults, networksetup.
Wenn kein Fix moeglich: nur NOFIX")
        if [ -n "$diag" ] && [ "$diag" != "NOFIX" ]; then
            log HEAL "Ollama Netzwerk-Fix:"
            echo "$diag" | while IFS= read -r line; do
                [ -n "$line" ] && log STEP "   > $line"
            done
            selfheal_apply "Network" "$diag"
            sleep 2
            for host in $NET_CHECK_HOSTS; do
                if ping -c 1 -W 3 "$host" &>/dev/null; then
                    log FIX "Netzwerk wiederhergestellt!"
                    report_add HEALED "Netzwerk via AI-Fix repariert"
                    return 0
                fi
            done
        fi
    fi

    report_add ERROR "No Internet connection"
    return 1
}

ensure_brew() {
    if ! command_exists brew; then
        log WARN "Homebrew not found. Installing..."
        run_or_dry /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        if command_exists brew; then
            log FIX "Homebrew installed."
            report_add FIX "Installed Homebrew"
            eval "$(/opt/homebrew/bin/brew shellenv)" 2>/dev/null || eval "$(/usr/local/bin/brew shellenv)" 2>/dev/null
        else
            log ERROR "Homebrew install failed."
            report_add ERROR "Homebrew missing"
            return 1
        fi
    else
        log STEP "   Homebrew gefunden: $(brew --prefix)"
    fi
    return 0
}

ensure_tool() {
    local cmd="$1"
    local pkg="$2"
    local is_cask="${3:-}"

    if command_exists "$cmd"; then
        log STEP "   Tool '$cmd' vorhanden"
        return 0
    fi

    log WARN "Tool '$cmd' fehlt. Installiere $pkg..."
    ensure_brew || return 1

    if run_or_dry brew install $is_cask "$pkg"; then
        log FIX "Installed '$pkg'."
        report_add FIX "Auto-installed: $pkg"
        return 0
    else
        log ERROR "Failed to install '$pkg'."
        report_add ERROR "Failed to install $pkg"

        if ollama_available; then
            log HEAL "Frage Ollama warum '$pkg' Installation fehlschlaegt..."
            local diag
            diag=$(selfheal_analyze "install-$pkg" "brew install $is_cask $pkg failed" "1")
            if [ -n "$diag" ] && [ "$diag" != "NOFIX" ]; then
                selfheal_apply "install-$pkg" "$diag"
                if run_or_dry brew install $is_cask "$pkg" 2>/dev/null; then
                    log FIX "Installation von '$pkg' nach AI-Fix erfolgreich!"
                    report_add HEALED "Install $pkg via AI-Fix"
                    return 0
                fi
            fi
        fi
        return 1
    fi
}

#############################
# 5. MODULES
#############################

# ── MIGRATION ──

MIGRATE_APPS=(
    "WhatsApp.app"
    "WhatsApp 2.app"
    "Google Chrome.app"
    "Firefox.app"
    "Slack.app"
    "Zoom.us.app"
    "Microsoft Word.app"
    "Microsoft Excel.app"
    "Microsoft PowerPoint.app"
    "Visual Studio Code.app"
    "Spotify.app"
    "Telegram.app"
    "VLC.app"
    "OneDrive.app"
)
MIGRATE_CASKS=(
    "whatsapp"
    ""
    "google-chrome"
    "firefox"
    "slack"
    "zoom"
    "microsoft-word"
    "microsoft-excel"
    "microsoft-powerpoint"
    "visual-studio-code"
    "spotify"
    "telegram"
    "vlc"
    "onedrive"
)

module_migration() {
    log INFO "Pruefe Apps fuer Migration von AppStore zu Brew..."
    ensure_brew || return 1
    local migrated_count=0
    local checked_count=0
    local i=0

    while [ $i -lt ${#MIGRATE_APPS[@]} ]; do
        local app_name="${MIGRATE_APPS[$i]}"
        local cask_name="${MIGRATE_CASKS[$i]}"
        local app_path="/Applications/$app_name"
        i=$((i + 1))
        checked_count=$((checked_count + 1))

        if [ -z "$cask_name" ]; then
            if [ -d "$app_path" ]; then
                log WARN "   Removing duplicate: $app_name"
                run_or_dry pkill -f "${app_name%.app}" &>/dev/null || true
                local owner=$(stat -f%Su "$app_path" 2>/dev/null)
                if [ "$owner" = "root" ]; then
                    run_or_dry sudo rm -rf "$app_path"
                else
                    run_or_dry rm -rf "$app_path"
                fi
                report_add FIX "Removed duplicate: $app_name"
                migrated_count=$((migrated_count + 1))
            fi
            continue
        fi

        if [ -d "$app_path" ] && [ -d "$app_path/Contents/_MASReceipt" ]; then
            log STEP "   MAS-App gefunden: $app_name"

            # Pruefen ob Cask deprecated ist
            local cask_info=$(brew info --cask "$cask_name" 2>&1)
            if echo "$cask_info" | grep -qi "deprecated\|disabled\|discontinued"; then
                log WARN "   Cask '$cask_name' ist deprecated - ueberspringe $app_name"
                report_add WARN "Migration uebersprungen: $app_name (Cask deprecated)"
                continue
            fi

            if echo "$cask_info" | grep -qi "$cask_name"; then
                log WARN "   MIGRATING $app_name -> Homebrew ($cask_name)..."
                run_or_dry pkill -f "${app_name%.app}" &>/dev/null || true

                # MAS-Apps gehoeren root, brauchen sudo
                local owner=$(stat -f%Su "$app_path" 2>/dev/null)
                if [ "$owner" = "root" ]; then
                    log STEP "   App gehoert root, verwende sudo rm"
                    run_or_dry sudo rm -rf "$app_path"
                else
                    run_or_dry rm -rf "$app_path"
                fi

                if [ -d "$app_path" ]; then
                    log ERROR "Konnte $app_name nicht loeschen (Rechte?)"
                    report_add ERROR "Migration failed: $app_name (rm fehlgeschlagen)"
                    continue
                fi

                if run_or_dry brew install --cask "$cask_name"; then
                    log FIX "Migrated $app_name to Brew."
                    report_add FIX "Migrated $app_name from MAS to Brew"
                    migrated_count=$((migrated_count + 1))
                else
                    log ERROR "Brew install failed for $cask_name!"
                    report_add ERROR "Migration failed: $app_name"
                fi
            fi
        fi
    done

    log INFO "   ${checked_count} Apps geprueft, ${migrated_count} migriert"
    [ $migrated_count -eq 0 ] && log INFO "   Alle Apps bereits auf Brew oder nicht MAS"
}

# ── HOMEBREW (Fix #4: korrekte Exit-Codes) ──

module_homebrew() {
    log INFO "Homebrew Wartung..."
    ensure_brew || return 1

    local brew_version=$(brew --version 2>/dev/null | head -1)
    log STEP "   Version: $brew_version"

    # brew update mit korrektem Exit-Code
    log INFO "   brew update..."
    run_verbose brew update
    local update_rc=$?
    if [ $update_rc -ne 0 ]; then
        log WARN "brew update fehlgeschlagen (Exit: $update_rc). Trying unshallow..."
        git -C "$(brew --repo)" fetch --unshallow &>/dev/null
        run_verbose brew update
        if [ $? -eq 0 ]; then
            report_add FIX "Fixed Homebrew repo (unshallow)"
        else
            log ERROR "brew update weiterhin fehlgeschlagen"
        fi
    fi

    # Outdated formulae
    log INFO "   Pruefe veraltete Formulae..."
    local outdated_formulae=$(brew outdated --formula 2>/dev/null)
    if [ -n "$outdated_formulae" ]; then
        local formula_count=$(echo "$outdated_formulae" | wc -l | xargs)
        log INFO "   ${formula_count} veraltete Formulae:"
        echo "$outdated_formulae" | while IFS= read -r line; do
            log STEP "     - $line"
        done
    else
        log INFO "   Alle Formulae aktuell"
    fi

    # brew upgrade mit korrektem Exit-Code
    log INFO "   brew upgrade..."
    run_verbose brew upgrade
    if [ $? -eq 0 ]; then
        report_add SUCCESS "Homebrew Formulae upgraded"
    else
        report_add WARN "Homebrew upgrade had issues"
    fi

    # Outdated casks
    log INFO "   Pruefe veraltete Casks..."
    local outdated_casks=$(brew outdated --cask --greedy 2>/dev/null)
    if [ -n "$outdated_casks" ]; then
        local cask_count=$(echo "$outdated_casks" | wc -l | xargs)
        log INFO "   ${cask_count} veraltete Casks:"
        echo "$outdated_casks" | while IFS= read -r line; do
            log STEP "     - $line"
        done
    else
        log INFO "   Alle Casks aktuell"
    fi

    # Fix #12: --greedy statt --force
    log INFO "   Upgrading Casks (--greedy)..."
    run_verbose brew upgrade --cask --greedy

    # Fix #23: autoremove nach upgrade
    log INFO "   Autoremove ungenutzter Dependencies..."
    local removed=$(brew autoremove 2>&1)
    if echo "$removed" | grep -q "Uninstalling"; then
        local rm_count=$(echo "$removed" | grep -c "Uninstalling")
        log FIX "   ${rm_count} ungenutzte Dependencies entfernt"
        report_add FIX "brew autoremove: ${rm_count} Pakete entfernt"
    else
        log STEP "   Keine ungenutzten Dependencies"
    fi

    log INFO "   Cleanup..."
    run_verbose brew cleanup -s
    report_add SUCCESS "Homebrew Cleanup finished"

    # Doctor-Check mit Auto-Fix (Fix #22)
    log INFO "   brew doctor..."
    local doctor_output=$(brew doctor 2>&1)
    if echo "$doctor_output" | grep -q "ready to brew"; then
        log INFO "   Homebrew ist gesund"
    else
        local warn_count=$(echo "$doctor_output" | grep -c "Warning" 2>/dev/null || echo 0)
        log WARN "   brew doctor: ${warn_count} Warnings"
        echo "$doctor_output" | grep "Warning" | head -5 | while IFS= read -r line; do
            log STEP "     $line"
        done

        # Auto-Fix: Unlinked kegs
        local did_autofix=false
        local unlinked=$(echo "$doctor_output" | grep -A20 "unlinked kegs" | grep "^  " | sed 's/^[[:space:]]*//' | head -10)
        if [ -n "$unlinked" ]; then
            log HEAL "   Auto-Fix: Unlinked Kegs linken..."
            did_autofix=true
            while IFS= read -r keg; do
                [ -z "$keg" ] && continue
                local keg_name=$(echo "$keg" | awk '{print $1}')
                if run_or_dry brew link "$keg_name" 2>/dev/null; then
                    log FIX "     Linked: $keg_name"
                    report_add FIX "brew link: $keg_name"
                else
                    log WARN "     Link fehlgeschlagen: $keg_name (versuche --overwrite)"
                    run_or_dry brew link --overwrite "$keg_name" 2>/dev/null && \
                        report_add FIX "brew link --overwrite: $keg_name"
                fi
            done <<< "$unlinked"
        fi

        # Auto-Fix: Outdated Xcode CLT
        if echo "$doctor_output" | grep -qi "command line tools.*outdated\|CLT.*update"; then
            log HEAL "   Auto-Fix: Xcode CLT Update anstossen..."
            did_autofix=true
            run_or_dry softwareupdate --install --all 2>/dev/null
            report_add FIX "Xcode CLT Update angestossen"
        fi

        # Auto-Fix: Broken symlinks
        if echo "$doctor_output" | grep -qi "broken symlinks"; then
            log HEAL "   Auto-Fix: Broken Symlinks bereinigen..."
            did_autofix=true
            brew cleanup -s 2>/dev/null
            report_add FIX "brew cleanup: Broken Symlinks bereinigt"
        fi

        # Fix #42: Re-check nur wenn tatsaechlich Auto-Fixes angewendet wurden
        if $did_autofix; then
            local doctor_recheck=$(brew doctor 2>&1)
            if echo "$doctor_recheck" | grep -q "ready to brew"; then
                log FIX "   Homebrew nach Auto-Fix gesund!"
                report_add FIX "brew doctor: Alle Warnings behoben"
            else
                local warn_remain=$(echo "$doctor_recheck" | grep -c "Warning" 2>/dev/null || echo 0)
                if [ "$warn_remain" -lt "$warn_count" ]; then
                    log FIX "   ${warn_count} -> ${warn_remain} Warnings reduziert"
                    report_add FIX "brew doctor: ${warn_count} -> ${warn_remain} Warnings"
                fi

                # Verbleibende Warnings an Ollama delegieren
                if [ "$warn_remain" -gt 0 ] && ollama_available; then
                    log HEAL "   Frage Ollama zu verbleibenden brew doctor Warnings..."
                    local safe_doctor=$(sanitize_for_prompt "$doctor_recheck" 800)
                    local doctor_fix
                    doctor_fix=$(selfheal_analyze "brew-doctor" "$safe_doctor" "1")
                    if [ -n "$doctor_fix" ] && [ "$doctor_fix" != "NOFIX" ]; then
                        selfheal_apply "brew-doctor" "$doctor_fix"
                        report_add HEALED "brew doctor: AI-Fix angewendet"
                    else
                        report_add WARN "brew doctor: ${warn_remain} Warnings verbleiben (siehe Log)"
                    fi
                else
                    report_add WARN "brew doctor: ${warn_remain} Warnings verbleiben (siehe Log)"
                fi
            fi
        else
            report_add WARN "brew doctor: ${warn_count} Warnings (kein Auto-Fix moeglich, siehe Log)"
        fi
    fi
}

# ── MAS (APP STORE) ──

module_mas() {
    log INFO "Pruefe Mac App Store..."
    ensure_tool "mas" "mas" || return 1

    # Fix #43: Pruefen ob User im App Store eingeloggt ist
    if ! mas account &>/dev/null; then
        log WARN "   Nicht im App Store eingeloggt - ueberspringe MAS-Updates"
        report_add WARN "App Store: Nicht eingeloggt (manuell anmelden)"
        return 0
    fi

    export MAS_NO_AUTO_INDEX=1

    local spotlight_marker="$MEISTER_DIR/spotlight_fixed"
    if [ ! -f "$spotlight_marker" ]; then
        log INFO "   Indexiere MAS-Apps fuer Spotlight (einmalig)..."
        local idx_count=0
        for app_dir in /Applications/*.app; do
            [ -d "$app_dir/Contents/_MASReceipt" ] || continue
            mdimport "$app_dir" &>/dev/null || true
            idx_count=$((idx_count + 1))
            log STEP "   Indexiert: $(basename "$app_dir")"
        done
        touch "$spotlight_marker"
        log FIX "Spotlight-Index fuer ${idx_count} MAS-Apps rebuilt"
        report_add FIX "Spotlight-Index fuer ${idx_count} App Store Apps repariert"
    fi

    log INFO "   Pruefe MAS-Updates..."
    local outdated=$(mas outdated 2>/dev/null)
    if [ -z "$outdated" ]; then
        log INFO "   Alle App Store Apps aktuell"
        report_add SUCCESS "App Store apps up to date"
    else
        local count=$(echo "$outdated" | wc -l | xargs)
        log INFO "   ${count} Updates verfuegbar:"
        echo "$outdated" | while IFS= read -r line; do
            log STEP "     - $line"
        done
        log INFO "   Installiere Updates..."
        run_verbose mas upgrade
        if [ $? -eq 0 ]; then
            report_add FIX "Updated $count App Store Apps"
        else
            report_add ERROR "MAS Upgrade failed"
        fi
    fi
}

# ── MS OFFICE (Timeout-Fix + Policy-Check + Retry) ──

# Fix #24: Sicherheitsrichtlinien fuer MS Updates pruefen
check_ms_update_policy() {
    log INFO "   Pruefe MS Update Sicherheitsrichtlinien..."

    # MDM-Profile die Updates blockieren koennten
    local profiles=$(profiles list 2>/dev/null || echo "")
    if echo "$profiles" | grep -qi "microsoft\|update.*restrict\|MAU\|com.microsoft"; then
        log WARN "   MDM-Profil koennte MS-Updates einschraenken"
        echo "$profiles" | grep -i "microsoft\|MAU" | head -3 | while IFS= read -r line; do
            log STEP "     $line"
        done
        report_add WARN "MDM-Profil fuer Microsoft gefunden (pruefen)"
    else
        log STEP "   Keine restriktiven MDM-Profile gefunden"
    fi

    # MAU-Channel pruefen
    local mau_channel=$(defaults read com.microsoft.autoupdate2 ChannelName 2>/dev/null)
    if [ -n "$mau_channel" ]; then
        log STEP "   MAU Channel: $mau_channel"
        if [ "$mau_channel" = "Custom" ]; then
            log WARN "   MAU Channel auf Custom - Updates koennten eingeschraenkt sein"
            report_add WARN "MAU Channel: Custom (ggf. auf Production setzen)"
        fi
    fi

    # Auto-Update Modus pruefen
    local mau_how=$(defaults read com.microsoft.autoupdate2 HowToCheck 2>/dev/null)
    if [ "$mau_how" = "Manual" ]; then
        log WARN "   MAU auf Manual gestellt - setze auf Automatic"
        run_or_dry defaults write com.microsoft.autoupdate2 HowToCheck Automatic
        report_add FIX "MAU HowToCheck: Manual -> Automatic"
    elif [ -n "$mau_how" ]; then
        log STEP "   MAU HowToCheck: $mau_how"
    fi

    # Auto-Download pruefen
    local mau_auto_dl=$(defaults read com.microsoft.autoupdate2 EnableCheckForUpdatesButton 2>/dev/null)
    if [ "$mau_auto_dl" = "0" ]; then
        log WARN "   MAU Update-Button deaktiviert - reaktiviere"
        run_or_dry defaults write com.microsoft.autoupdate2 EnableCheckForUpdatesButton -bool true
        report_add FIX "MAU Update-Button reaktiviert"
    fi

    # Full Disk Access Hinweis (nur Info, kann nicht automatisch geaendert werden)
    if [ -f "/Library/Application Support/com.apple.TCC/TCC.db" ]; then
        local has_fda
        has_fda=$(sudo sqlite3 "/Library/Application Support/com.apple.TCC/TCC.db" \
            "SELECT client FROM access WHERE service='kTCCServiceSystemPolicyAllFiles' AND auth_value=2" 2>/dev/null \
            | grep -ci "microsoft" 2>/dev/null) || has_fda=0
        if [ "${has_fda:-0}" -eq 0 ]; then
            log WARN "   MS AutoUpdate hat moeglicherweise keinen Full Disk Access"
            report_add WARN "MS AutoUpdate: Full Disk Access pruefen (Systemeinstellungen > Datenschutz)"
        else
            log STEP "   MS Apps haben Full Disk Access"
        fi
    fi
}

module_office() {
    log INFO "Microsoft Office Updates..."
    if [ ! -f "$MSUPDATE_PATH" ]; then
        log WARN "   MS AutoUpdate nicht gefunden"
        log STEP "   Pfad: $MSUPDATE_PATH"
        report_add WARN "MS AutoUpdate not found (Skipped)"
        return 0
    fi

    if $DRY_RUN; then
        log STEP "   [DRY-RUN] wuerde msupdate --install ausfuehren"
        return 0
    fi

    # Fix #24: Policy-Check vor Update
    check_ms_update_policy

    log INFO "   MS AutoUpdate gefunden, pruefe verfuegbare Updates..."

    # Erst --list ausfuehren um zu pruefen ob Updates verfuegbar sind
    # (--install haengt wenn keine Updates vorhanden)
    local list_file=$(mktemp /tmp/msupdate_list_XXXXXX.log 2>/dev/null || echo "/tmp/msupdate_list_$$.log")
    timeout "$MSUPDATE_TIMEOUT" "$MSUPDATE_PATH" --list > "$list_file" 2>&1
    local list_rc=$?
    local list_output=$(cat "$list_file" 2>/dev/null)
    rm -f "$list_file" 2>/dev/null

    if [ $list_rc -eq 124 ]; then
        log WARN "   msupdate --list Timeout nach ${MSUPDATE_TIMEOUT}s"
        report_add WARN "Office Update: --list Timeout (manuell pruefen)"
        pkill -f "Microsoft AutoUpdate" 2>/dev/null || true
        pkill -f "Microsoft Update Assistant" 2>/dev/null || true
        return 0
    fi

    # ANSI-Escape-Codes entfernen fuer sauberen Vergleich
    local clean_output=$(echo "$list_output" | sed $'s/\x1b\\[[0-9;]*[a-zA-Z]//g' | tr -s ' ')

    if echo "$clean_output" | grep -qi "No updates"; then
        log INFO "   Office ist aktuell (keine Updates verfuegbar)"
        MSUPDATE_OUTPUT_LOG="$list_output"
        report_add SUCCESS "Office is up to date"
        return 0
    fi

    # Updates verfuegbar - anzeigen was kommt
    log INFO "   Updates verfuegbar:"
    echo "$clean_output" | grep -v '^$' | while IFS= read -r line; do
        [ -n "$line" ] && log STEP "   $line"
    done

    # Jetzt --install ausfuehren
    log INFO "   Starte Installation..."
    log STEP "   Timeout: ${MSUPDATE_TIMEOUT}s"

    local output_file=$(mktemp /tmp/msupdate_XXXXXX.log 2>/dev/null || echo "/tmp/msupdate_$$.log")

    "$MSUPDATE_PATH" --install > "$output_file" 2>&1 &
    local ms_pid=$!
    log STEP "   msupdate PID: $ms_pid"

    local waited=0
    local dot_count=0
    while kill -0 "$ms_pid" 2>/dev/null && [ $waited -lt $MSUPDATE_TIMEOUT ]; do
        sleep 5
        waited=$((waited + 5))
        dot_count=$((dot_count + 1))
        if [ $((dot_count % 3)) -eq 0 ]; then
            log STEP "   Warte auf msupdate... (${waited}s/${MSUPDATE_TIMEOUT}s)"
            local current_output=$(tail -1 "$output_file" 2>/dev/null)
            [ -n "$current_output" ] && log STEP "   Status: $current_output"
        fi
    done

    if kill -0 "$ms_pid" 2>/dev/null; then
        log WARN "   msupdate haengt nach ${MSUPDATE_TIMEOUT}s - beende Prozess!"
        kill "$ms_pid" 2>/dev/null
        sleep 2
        if kill -0 "$ms_pid" 2>/dev/null; then
            log WARN "   Force-Kill msupdate..."
            kill -9 "$ms_pid" 2>/dev/null
        fi
        wait "$ms_pid" 2>/dev/null

        local stuck_output=$(cat "$output_file" 2>/dev/null)
        MSUPDATE_OUTPUT_LOG="[TIMEOUT nach ${MSUPDATE_TIMEOUT}s] $stuck_output"
        report_add WARN "Office Update Timeout nach ${MSUPDATE_TIMEOUT}s (manuell pruefen)"

        # Auch MAU-Hilfsprozesse killen die haengen bleiben
        log STEP "   Beende verwaiste MAU-Prozesse..."
        pkill -f "Microsoft AutoUpdate" 2>/dev/null || true
        pkill -f "Microsoft Update Assistant" 2>/dev/null || true

        if ollama_available; then
            log HEAL "Frage Ollama warum MS Update haengt..."
            local safe_output=$(sanitize_for_prompt "$stuck_output" 500)
            local diag
            diag=$(ollama_query "msupdate (Microsoft AutoUpdate auf macOS) haengt seit ${MSUPDATE_TIMEOUT} Sekunden.
Output: $safe_output
Shell-Commands, eine pro Zeile. Keine Erklaerungen, kein Markdown, keine <think>-Tags. Wenn kein Fix: nur NOFIX")
            if [ -n "$diag" ] && [ "$diag" != "NOFIX" ]; then
                log HEAL "Ollama MS-Update Fix:"
                echo "$diag" | while IFS= read -r line; do
                    [ -n "$line" ] && log STEP "   > $line"
                done
                selfheal_apply "MSUpdate-Stuck" "$diag"
                report_add HEALED "MS Update: AI-Fix angewendet"
            fi
        fi

        # Fix #25: Retry nach Timeout
        log INFO "   Office-Update Retry nach Timeout..."
        sleep 5
        local retry_file=$(mktemp /tmp/msupdate_retry_XXXXXX.log 2>/dev/null || echo "/tmp/msupdate_retry_$$.log")
        timeout "$MSUPDATE_TIMEOUT" "$MSUPDATE_PATH" --install > "$retry_file" 2>&1
        local retry_rc=$?
        local retry_output=$(cat "$retry_file" 2>/dev/null)
        rm -f "$retry_file" 2>/dev/null

        if [ $retry_rc -eq 0 ]; then
            log FIX "   Retry: Office Updates installiert!"
            report_add FIX "Office Update via Retry erfolgreich"
        elif [ $retry_rc -eq 124 ]; then
            log ERROR "   Retry: Erneuter Timeout"
            report_add ERROR "Office Update: Timeout auch nach Retry (manuell pruefen)"
        else
            log WARN "   Retry: Exit $retry_rc"
            report_add WARN "Office Update Retry: Exit $retry_rc (manuell pruefen)"
        fi
    else
        wait "$ms_pid" 2>/dev/null
        local code=$?
        local output=$(cat "$output_file" 2>/dev/null)
        MSUPDATE_OUTPUT_LOG="$output"

        if [ $code -eq 0 ]; then
            log FIX "Office Updates installiert"
            echo "$output" | sed $'s/\x1b\\[[0-9;]*[a-zA-Z]//g' | grep -v '^$' | while IFS= read -r line; do
                [ -n "$line" ] && log STEP "   $line"
            done
            report_add FIX "Office updates installed"
        else
            log ERROR "Office update fehlgeschlagen (Exit: $code)"
            echo "$output" | tail -5 | while IFS= read -r line; do
                [ -n "$line" ] && log STEP "   $line"
            done
            report_add ERROR "Office update failed (Exit: $code)"
        fi
    fi

    rm -f "$output_file" 2>/dev/null
}

# ── OLLAMA (Fix #5: Subshell-Counter-Bug) ──

module_ollama() {
    log INFO "Pruefe Ollama..."

    if ! command_exists ollama; then
        if command_exists brew && brew list --cask ollama &>/dev/null; then
            ensure_tool "ollama" "ollama" "--cask"
        else
            log INFO "   Ollama nicht installiert. Ueberspringe."
            return 0
        fi
    fi

    if ! command_exists ollama; then return 0; fi

    # Fix #41: Zentralen Starter verwenden
    if ollama_available; then
        log INFO "   Ollama-Server laeuft"
    elif ensure_ollama_running "   "; then
        report_add FIX "Ollama-Server automatisch gestartet"
    else
        report_add WARN "Ollama-Server offline"
    fi

    local models=$(ollama list 2>/dev/null | awk 'NR>1 {print $1}')
    if [ -z "$models" ]; then
        log INFO "   Keine Ollama-Modelle installiert"
        return 0
    fi

    local model_count=$(echo "$models" | wc -l | xargs)
    log INFO "   ${model_count} Modelle gefunden"

    # Fix #5: Kein Pipe, kein Subshell-Problem
    local updated=0
    local failed=0
    for model in $models; do
        log INFO "   Pulling: $model"
        local pull_output
        pull_output=$(run_or_dry ollama pull "$model" 2>&1)
        local pull_rc=$?
        if [ $pull_rc -eq 0 ]; then
            updated=$((updated + 1))
            log STEP "     OK"
        else
            failed=$((failed + 1))
            log WARN "   Pull fehlgeschlagen: $model"
            [ -n "$pull_output" ] && log STEP "     $(echo "$pull_output" | tail -1)"
        fi
    done

    log INFO "   ${updated}/${model_count} Modelle aktualisiert"
    [ $failed -gt 0 ] && log WARN "   ${failed} Pulls fehlgeschlagen"
    report_add FIX "Updated $updated/$model_count Ollama models"

    if $RUN_LMSTUDIO_COPY; then
        log INFO "   Sync GGUF-Modelle zu LM Studio..."
        local dest="$HOME/Library/Application Support/LM Studio/models"
        mkdir -p "$dest"
        local synced=0
        while IFS= read -r -d '' f; do
            local bname=$(basename "$f")
            if [ ! -f "$dest/$bname" ]; then
                run_or_dry cp "$f" "$dest/"
                synced=$((synced + 1))
                log STEP "     Synced: $bname"
            fi
        done < <(find "$HOME/.ollama/models" -name "*.gguf" -print0 2>/dev/null)
        log INFO "   ${synced} Modelle synchronisiert"
        report_add FIX "Synced $synced GGUF models to LM Studio"
    fi
}

# ── CLAMAV (Fix #15: bessere Excludes) ──

module_clamav() {
    log INFO "ClamAV Modul..."
    ensure_tool "clamscan" "clamav" || return 1

    local config_dir="$(brew --prefix)/etc/clamav"
    local db_dir="$(brew --prefix)/var/lib/clamav"
    log STEP "   Config: $config_dir"
    log STEP "   DB: $db_dir"

    if [ ! -f "$config_dir/freshclam.conf" ]; then
        log WARN "freshclam.conf fehlt..."
        if [ -f "$config_dir/freshclam.conf.sample" ]; then
            run_or_dry sudo cp "$config_dir/freshclam.conf.sample" "$config_dir/freshclam.conf"
            run_or_dry sudo sed -i '' 's/^Example/#Example/' "$config_dir/freshclam.conf"
            log FIX "freshclam.conf erstellt"
            report_add FIX "Created freshclam.conf"
        else
            log ERROR "freshclam.conf.sample nicht gefunden"
            report_add ERROR "freshclam.conf.sample not found"
            return 1
        fi
    fi

    [ ! -d "$db_dir" ] && mkdir -p "$db_dir" && report_add FIX "Created ClamAV DB dir"

    log INFO "   Aktualisiere Virus-Definitionen..."
    run_verbose sudo freshclam
    if [ $? -eq 0 ]; then
        report_add SUCCESS "Virus definitions updated"
    else
        report_add WARN "freshclam reported an issue"
    fi

    if $DRY_RUN; then
        log STEP "   [DRY-RUN] wuerde clamscan auf $HOME ausfuehren"
        return 0
    fi

    # Fix #39: Exclude-Liste als Array (kein eval noetig)
    log INFO "   Scanne $HOME (kann dauern)..."
    local -a exclude_args=(
        --exclude-dir='^/Volumes'
        '--exclude-dir=\.ollama/models'
        '--exclude-dir=Library/Application Support/LM Studio'
        '--exclude-dir=Library/Caches'
        '--exclude-dir=\.Trash'
        '--exclude-dir=node_modules'
        '--exclude-dir=\.git/objects'
        '--exclude-dir=miniforge3'
        '--exclude-dir=Parallels'
        '--exclude-dir=Venvs'
        '--exclude-dir=go/pkg'
    )

    log STEP "   Excludes: Volumes, .ollama/models, Caches, .Trash, node_modules, .git, miniforge3, Parallels, Venvs, go/pkg"

    local scan_start=$(date +%s)

    clamscan -r --bell -i "${exclude_args[@]}" "$HOME" 2>&1 | while IFS= read -r line; do
        case "$line" in
            *FOUND*) log ERROR "   FUND: $line" ;;
            *"Scanned files"*|*"Infected files"*|*"Time"*|*"Known viruses"*)
                log INFO "   $line" ;;
        esac
    done
    local scan_rc=${PIPESTATUS[0]}

    local scan_end=$(date +%s)
    local scan_dur=$(( (scan_end - scan_start) / 60 ))
    log INFO "   Scan abgeschlossen in ~${scan_dur} Minuten"

    if [ "$scan_rc" -eq 0 ]; then
        report_add SUCCESS "ClamAV: No Malware Found"
    elif [ "$scan_rc" -eq 1 ]; then
        report_add ERROR "MALWARE FOUND! CHECK LOGS!"
        log ERROR "MALWARE FOUND!"
    else
        report_add WARN "ClamAV Scan beendet (Exit: $scan_rc)"
    fi
}

# ── SYSTEM & CLEANUP ──

module_system() {
    log INFO "macOS System-Update Pruefung..."
    log STEP "   Pruefe softwareupdate..."
    local sysup=$(softwareupdate -l 2>&1)

    if echo "$sysup" | grep -q "No new software"; then
        log INFO "   macOS ist aktuell"
        report_add SUCCESS "macOS is up to date"
    else
        local update_count=$(echo "$sysup" | grep -c "^\*" 2>/dev/null || echo "?")
        log WARN "   ${update_count} macOS Updates verfuegbar:"
        echo "$sysup" | grep "^\*\|Label\|Title" | while IFS= read -r line; do
            log STEP "     $line"
        done

        # Fix #26: Recommended Updates automatisch installieren (kein Restart)
        local has_restart=$(echo "$sysup" | grep -ci "restart" 2>/dev/null || echo 0)
        local has_recommended=$(echo "$sysup" | grep -ci "Recommended: YES" 2>/dev/null || echo 0)

        if [ "$has_recommended" -gt 0 ] && [ "$has_restart" -eq 0 ]; then
            log INFO "   Installiere empfohlene Updates (kein Restart noetig)..."
            run_verbose sudo softwareupdate --install --recommended --agree-to-license
            if [ $? -eq 0 ]; then
                report_add FIX "macOS Recommended Updates installiert"
            else
                report_add WARN "macOS Update Installation fehlgeschlagen"
            fi
        elif [ "$has_restart" -gt 0 ]; then
            log WARN "   Updates benoetigen Restart - ueberspringe Auto-Install"
            report_add WARN "macOS Update verfuegbar (Restart noetig, manuell installieren)"
        else
            report_add WARN "macOS Update Available ($update_count)"
        fi
    fi

    # Disk-Usage Check
    local disk_pct=$(df -h / | awk 'NR==2 {gsub(/%/,"",$5); print $5}')
    local disk_free=$(df -h / | awk 'NR==2 {print $4}')
    log INFO "   Disk: ${disk_pct}% belegt, ${disk_free} frei"
    if [ "$disk_pct" -gt "$DISK_USAGE_THRESHOLD" ] 2>/dev/null; then
        log WARN "   Disk-Usage ueber ${DISK_USAGE_THRESHOLD}%!"
        report_add WARN "Disk usage: ${disk_pct}% (>${DISK_USAGE_THRESHOLD}%)"

        if ollama_available; then
            log HEAL "Frage Ollama nach Platz-Tipps..."
            local tip
            tip=$(ollama_query "macOS Disk ${disk_pct}% voll, ${disk_free} frei. Liste 3-5 sichere Shell-Befehle um Platz zu schaffen. Nur Commands, eine pro Zeile. Keine Erklaerungen, keine <think>-Tags.")
            if [ -n "$tip" ] && [ "$tip" != "NOFIX" ]; then
                log HEAL "Ollama Platz-Tipps:"
                echo "$tip" | while IFS= read -r line; do
                    [ -n "$line" ] && log STEP "   > $line"
                done
                report_add WARN "Ollama Platz-Tipps im Log (manuell pruefen)"
            fi
        fi
    fi
}

module_cleanup() {
    log INFO "Bereinigung..."

    if $CLEAN_XCODE; then
        local xcpath="$HOME/Library/Developer/Xcode/DerivedData"
        if [ -d "$xcpath" ]; then
            local xc_size=$(du -sh "$xcpath" 2>/dev/null | awk '{print $1}')
            log INFO "   Loesche Xcode DerivedData ($xc_size)..."
            run_or_dry rm -rf "$xcpath"
            report_add FIX "Deleted Xcode DerivedData ($xc_size)"
        else
            log INFO "   Kein Xcode DerivedData vorhanden"
        fi
    else
        log STEP "   Xcode clean: uebersprungen (-X)"
    fi

    if $RUN_MONOLINGUAL; then
        ensure_tool "monolingual" "monolingual"
        report_add WARN "Monolingual installed (Run manually)"
    else
        log STEP "   Monolingual: uebersprungen (-M)"
    fi

    if $EMPTY_TRASH; then
        local trash_count=$(ls -1 "$HOME/.Trash" 2>/dev/null | wc -l | xargs)
        log INFO "   Leere Papierkorb ($trash_count Elemente)..."
        run_or_dry rm -rf "$HOME/.Trash"/*
        report_add FIX "Emptied Trash ($trash_count items)"
    else
        log STEP "   Papierkorb: uebersprungen (-T)"
    fi

    if $CLEAN_CACHES; then
        local cache_size=$(du -sh "$HOME/Library/Caches" 2>/dev/null | awk '{print $1}')
        log INFO "   Loesche User Caches ($cache_size)..."
        run_or_dry rm -rf "$HOME/Library/Caches"/*
        report_add FIX "Cleaned User Caches ($cache_size)"
        if $NEEDS_SUDO; then
            log INFO "   Loesche System Caches (sudo)..."
            run_or_dry sudo rm -rf /Library/Caches/* /System/Library/Caches/* /private/var/tmp/*
            report_add FIX "Cleaned System Caches"
        fi
    else
        log STEP "   Cache clean: uebersprungen (-C)"
    fi

    if $LIST_LARGE_FILES; then
        log INFO "   Suche Dateien groesser ${LARGE_FILE_SIZE_MB}MB..."
        local large_files=$(find "$HOME" -xdev -type f -size +${LARGE_FILE_SIZE_MB}M -print0 2>/dev/null | xargs -0 ls -lh 2>/dev/null | awk '{print $5, $9}')
        if [ -n "$large_files" ]; then
            local lf_count=$(echo "$large_files" | wc -l | xargs)
            log INFO "   ${lf_count} grosse Dateien gefunden:"
            echo "$large_files" | head -10 | while IFS= read -r line; do
                log STEP "     $line"
            done
            [ "$lf_count" -gt 10 ] && log STEP "     ... und $((lf_count - 10)) weitere (siehe Log)"
            echo "$large_files" >> "$LOGFILE"
        else
            log INFO "   Keine Dateien groesser ${LARGE_FILE_SIZE_MB}MB"
        fi
        report_add SUCCESS "Large files logged"
    else
        log STEP "   Grosse Dateien: uebersprungen (-L)"
    fi
}

#############################
# 6. SELF-HEALING PREFLIGHT
#############################

selfheal_preflight() {
    log INFO "Self-Healing Preflight Check..."

    if command_exists brew; then
        log STEP "   Pruefe Homebrew-Zustand..."
        if ! brew --prefix &>/dev/null; then
            log WARN "   Homebrew reagiert nicht"
            if ollama_available; then
                local diag
                diag=$(selfheal_analyze "brew-preflight" "brew --prefix returns error or hangs" "1")
                if [ -n "$diag" ] && [ "$diag" != "NOFIX" ]; then
                    selfheal_apply "brew-preflight" "$diag"
                    report_add HEALED "Homebrew via Preflight repariert"
                fi
            fi
        else
            log STEP "   Homebrew OK"
        fi
    fi

    log STEP "   Pruefe DNS..."
    if ! host google.com &>/dev/null 2>&1; then
        log WARN "   DNS-Aufloesung fehlgeschlagen"
        sudo dscacheutil -flushcache 2>/dev/null
        sudo killall -HUP mDNSResponder 2>/dev/null
        sleep 1
        if host google.com &>/dev/null 2>&1; then
            log FIX "   DNS nach Flush OK"
            report_add FIX "DNS-Cache geleert (Preflight)"
        fi
    else
        log STEP "   DNS OK"
    fi

    local disk_pct=$(df -h / | awk 'NR==2 {gsub(/%/,"",$5); print $5}')
    if [ "$disk_pct" -gt "$DISK_CRITICAL_THRESHOLD" ] 2>/dev/null; then
        log ERROR "   KRITISCH: Disk ${disk_pct}% voll!"
        log WARN "   Raeume Temp-Dateien auf..."
        rm -rf /private/var/tmp/* 2>/dev/null
        rm -rf "$HOME/Library/Caches"/* 2>/dev/null
        report_add HEALED "Notfall-Cleanup bei ${disk_pct}% Disk"
    elif [ "$disk_pct" -gt "$DISK_USAGE_THRESHOLD" ] 2>/dev/null; then
        log WARN "   Disk ${disk_pct}% belegt (Schwelle: ${DISK_USAGE_THRESHOLD}%)"
    else
        log STEP "   Disk OK (${disk_pct}%)"
    fi

    log INFO "   Preflight abgeschlossen"
}

#############################
# 7. MAIN
#############################

keep_sudo() {
    sudo -v
    while true; do sudo -n true; sleep 60; kill -0 "$$" || exit; done 2>/dev/null &
    SUDO_KEEPALIVE_PID=$!
}

# Fix #16: Run-History
save_history() {
    local history_file="$MEISTER_DIR/history.log"
    local end_ts=$(date +%s)
    local total_secs=$((end_ts - SCRIPT_START_TIME))
    local total_mins=$((total_secs / 60))
    local total_secs_rem=$((total_secs % 60))
    local ts=$(date +'%Y-%m-%d %H:%M:%S')
    local h_count h_ok h_fail h_cached h_secs
    read -r h_count h_ok h_fail h_cached h_secs < <(ollama_stat_read)
    echo "$ts | ${total_mins}m${total_secs_rem}s | OK:${#REPORT_SUCCESS[@]} FIX:${#REPORT_FIXED[@]} WARN:${#REPORT_WARNINGS[@]} ERR:${#REPORT_ERRORS[@]} HEAL:${#REPORT_HEALED[@]} | AI:${h_ok}/${h_count}(${h_cached}c)" >> "$history_file"
}

print_report() {
    local end_ts=$(date +%s)
    local total_secs=$((end_ts - SCRIPT_START_TIME))
    local total_mins=$((total_secs / 60))
    local total_secs_rem=$((total_secs % 60))

    echo ""
    echo -e "${BLUE}====================================================${NC}"
    echo -e "${BLUE}   MEISTER REPORT (v11.0)${NC}"
    echo -e "${BLUE}   Laufzeit: ${total_mins}m ${total_secs_rem}s${NC}"
    $DRY_RUN && echo -e "${YELLOW}   [DRY-RUN MODUS]${NC}"
    echo -e "${BLUE}====================================================${NC}"

    if [ ${#REPORT_SUCCESS[@]} -gt 0 ]; then
        echo -e "\n${GREEN}SUCCESS (${#REPORT_SUCCESS[@]}):${NC}"
        printf '  - %s\n' "${REPORT_SUCCESS[@]}"
    fi
    if [ ${#REPORT_FIXED[@]} -gt 0 ]; then
        echo -e "\n${CYAN}FIXED (${#REPORT_FIXED[@]}):${NC}"
        printf '  - %s\n' "${REPORT_FIXED[@]}"
    fi
    if [ ${#REPORT_HEALED[@]} -gt 0 ]; then
        echo -e "\n${MAGENTA}AI-HEALED via Ollama (${#REPORT_HEALED[@]}):${NC}"
        printf '  - %s\n' "${REPORT_HEALED[@]}"
    fi
    if [ ${#REPORT_WARNINGS[@]} -gt 0 ]; then
        echo -e "\n${YELLOW}WARNINGS (${#REPORT_WARNINGS[@]}):${NC}"
        printf '  - %s\n' "${REPORT_WARNINGS[@]}"
    fi
    if [ ${#REPORT_ERRORS[@]} -gt 0 ]; then
        echo -e "\n${RED}ERRORS (${#REPORT_ERRORS[@]}):${NC}"
        printf '  - %s\n' "${REPORT_ERRORS[@]}"
    fi
    if [ -n "$MSUPDATE_OUTPUT_LOG" ]; then
        echo -e "\n${BLUE}--- MS Update Detail ---${NC}"
        echo "$MSUPDATE_OUTPUT_LOG"
    fi

    # Fix #51: Ollama-Statistik im Report (dateibasiert)
    local o_count o_ok o_fail o_cached o_secs
    read -r o_count o_ok o_fail o_cached o_secs < <(ollama_stat_read)
    if [ "${o_count:-0}" -gt 0 ]; then
        echo -e "\n${MAGENTA}--- Ollama Statistik ---${NC}"
        echo "  Modell:  $OLLAMA_MODEL"
        echo "  Queries: $o_count (OK: $o_ok, Fehler: $o_fail, Cache: $o_cached)"
        local non_cached=$((o_count - o_cached))
        if [ "$non_cached" -gt 0 ] && [ "${o_secs:-0}" -gt 0 ]; then
            local avg=$((o_secs / non_cached))
            echo "  Dauer:   ${o_secs}s gesamt (~${avg}s/Query)"
        fi
    fi

    echo -e "\n${BLUE}====================================================${NC}"
    echo "Log: $LOGFILE"
    echo "Config: $MEISTER_CONFIG"
}

health_dashboard() {
    echo -e "\n${MAGENTA}═══════════════════════════════════════${NC}"
    echo -e "${MAGENTA}  Self-Healing Status (v11.0)${NC}"
    echo -e "${MAGENTA}═══════════════════════════════════════${NC}"
    if ollama_available; then
        echo -e "  Ollama:  ${GREEN}online${NC} ($OLLAMA_MODEL)"
        local model_count=$(ollama list 2>/dev/null | awk 'NR>1' | wc -l | xargs)
        echo -e "  Modelle: ${model_count}"
        echo -e "  Timeout: ${OLLAMA_QUERY_TIMEOUT}s (+${OLLAMA_COLD_START_EXTRA}s Cold-Start)"
        echo -e "  Fallback: ${OLLAMA_FALLBACK_MODEL}"
        local cache_count=$(ls -1 "$MEISTER_DIR/cache/" 2>/dev/null | wc -l | xargs)
        echo -e "  Cache:   ${cache_count} Eintraege"
    else
        echo -e "  Ollama:  ${RED}offline${NC}"
    fi
    echo -e "  System:  $(get_system_context 2>/dev/null || echo 'n/a')"
    echo -e "  Disk:    $(df -h / | awk 'NR==2 {print $5}') belegt ($(df -h / | awk 'NR==2 {print $4}') frei)"
    local pc=$(ls -1 "$MEISTER_DIR/patches/" 2>/dev/null | wc -l | xargs)
    echo -e "  Patches: ${pc} gespeichert"
    if [ $pc -gt 0 ]; then
        echo -e "  Letzte:"
        ls -1t "$MEISTER_DIR/patches/" 2>/dev/null | head -5 | while IFS= read -r f; do
            echo -e "    - $f"
        done
    fi
    # Run History
    local history_file="$MEISTER_DIR/history.log"
    if [ -f "$history_file" ]; then
        local run_count=$(wc -l < "$history_file" | xargs)
        echo -e "  Runs:    ${run_count} gesamt"
        echo -e "  Letzte Laeufe:"
        tail -5 "$history_file" | while IFS= read -r line; do
            echo -e "    $line"
        done
    fi
    echo -e "  Config:  $MEISTER_CONFIG"
    echo -e "${MAGENTA}═══════════════════════════════════════${NC}"
}

# Fix #50: Fehlerbehandlung in ollama_summary
ollama_summary() {
    if ! ollama_available; then
        log STEP "   Ollama offline - keine AI-Zusammenfassung"
        return
    fi

    local total=$((${#REPORT_SUCCESS[@]} + ${#REPORT_FIXED[@]} + ${#REPORT_WARNINGS[@]} + ${#REPORT_ERRORS[@]} + ${#REPORT_HEALED[@]}))
    [ $total -eq 0 ] && return

    log HEAL "Erstelle AI-Zusammenfassung..."
    local summary_prompt="Du bist ein macOS Admin. Fasse diesen Wartungsbericht kurz zusammen (max 3 Saetze, Deutsch):
OK: ${REPORT_SUCCESS[*]:-keine}
Fixed: ${REPORT_FIXED[*]:-keine}
Warnings: ${REPORT_WARNINGS[*]:-keine}
Errors: ${REPORT_ERRORS[*]:-keine}
AI-Healed: ${REPORT_HEALED[*]:-keine}
Gib eine kurze Bewertung und ggf. empfohlene naechste Schritte. Keine <think>-Tags."

    local summary
    # Kein Cache fuer Summary (jeder Lauf hat andere Daten)
    summary=$(ollama_query "$summary_prompt" "false")
    if [ -n "$summary" ]; then
        echo ""
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo -e "${MAGENTA}  AI-Zusammenfassung (${OLLAMA_MODEL})${NC}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo "$summary" | while IFS= read -r line; do
            echo -e "  $line"
        done
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    else
        log WARN "   AI-Zusammenfassung fehlgeschlagen (Ollama-Query Timeout oder Fehler)"
        report_add WARN "AI-Zusammenfassung konnte nicht erstellt werden"
    fi
}

#############################
# 8. LOG-ANALYSE (Fix #27)
#############################

log_analysis() {
    local history_file="$MEISTER_DIR/history.log"
    [ ! -f "$history_file" ] && return
    local run_count=$(wc -l < "$history_file" | xargs)
    [ "$run_count" -lt 3 ] && return

    log INFO "Log-Analyse: Pruefe wiederkehrende Probleme..."

    # Warnings und Errors aus letzten 5 Runs zaehlen
    local recent_warns=""
    if [ -f "$LOGFILE" ]; then
        recent_warns=$(grep -E "^.* - (WARN|ERROR) - " "$LOGFILE" 2>/dev/null | \
            sed 's/^.* - \(WARN\|ERROR\) - //' | sort | uniq -c | sort -rn | head -10)
    fi

    # Auch .old Log einbeziehen
    if [ -f "${LOGFILE}.old" ]; then
        local old_warns=$(grep -E "^.* - (WARN|ERROR) - " "${LOGFILE}.old" 2>/dev/null | \
            sed 's/^.* - \(WARN\|ERROR\) - //' | sort | uniq -c | sort -rn | head -10)
        if [ -n "$old_warns" ]; then
            recent_warns=$(echo -e "${recent_warns}\n${old_warns}" | sort -rn | head -10)
        fi
    fi

    if [ -n "$recent_warns" ]; then
        local recurring=$(echo "$recent_warns" | awk '$1 >= 3 {$1=""; print}' | sed 's/^ //')
        if [ -n "$recurring" ]; then
            log WARN "   Wiederkehrende Probleme erkannt:"
            echo "$recurring" | while IFS= read -r line; do
                [ -n "$line" ] && log STEP "     - $line"
            done
            report_add WARN "Wiederkehrende Probleme erkannt (siehe Log)"

            # Ollama um Analyse bitten
            if ollama_available; then
                local safe_recurring=$(sanitize_for_prompt "$recurring" 500)
                local analysis
                analysis=$(ollama_query "Diese macOS-Wartungsprobleme treten wiederholt auf:
${safe_recurring}
Gib eine kurze Analyse (max 3 Saetze) und konkrete Loesungsvorschlaege. Deutsch.")
                if [ -n "$analysis" ]; then
                    log HEAL "   AI-Analyse wiederkehrender Probleme:"
                    echo "$analysis" | while IFS= read -r line; do
                        [ -n "$line" ] && log STEP "     $line"
                    done
                fi
            fi
        else
            log STEP "   Keine wiederkehrenden Probleme"
        fi
    fi
}

#############################
# 9. NOTIFICATIONS (Fix #28, #29)
#############################

# Fix #28: terminal-notifier mit Fallback
send_notification() {
    local title="$1"
    local message="$2"
    local subtitle="${3:-}"

    if command_exists terminal-notifier; then
        local tn_args=(-title "$title" -message "$message" -group "meister")
        [ -n "$subtitle" ] && tn_args+=(-subtitle "$subtitle")
        # Clickable: oeffnet Logfile
        tn_args+=(-open "file://$LOGFILE")
        terminal-notifier "${tn_args[@]}" 2>/dev/null
    else
        local osa_msg="$message"
        [ -n "$subtitle" ] && osa_msg="$subtitle: $message"
        osascript -e "display notification \"$osa_msg\" with title \"$title\"" 2>/dev/null
    fi
}

# Fix #29: Pushover-Benachrichtigung
send_pushover() {
    [ -z "$PUSHOVER_USER" ] || [ -z "$PUSHOVER_TOKEN" ] && return
    local title="$1"
    local message="$2"
    local priority="${3:-0}"

    curl -sf --max-time 10 \
        --form-string "token=$PUSHOVER_TOKEN" \
        --form-string "user=$PUSHOVER_USER" \
        --form-string "title=$title" \
        --form-string "message=$message" \
        --form-string "priority=$priority" \
        https://api.pushover.net/1/messages.json >/dev/null 2>&1

    if [ $? -eq 0 ]; then
        log STEP "   Pushover-Benachrichtigung gesendet"
    else
        log WARN "   Pushover-Benachrichtigung fehlgeschlagen"
    fi
}

# Report-Zusammenfassung als String
build_report_summary() {
    local summary="OK:${#REPORT_SUCCESS[@]} FIX:${#REPORT_FIXED[@]} WARN:${#REPORT_WARNINGS[@]} ERR:${#REPORT_ERRORS[@]} HEAL:${#REPORT_HEALED[@]}"
    local end_ts=$(date +%s)
    local total_mins=$(( (end_ts - SCRIPT_START_TIME) / 60 ))
    echo "Meister v11.0 | ${total_mins}min | $summary"
}

send_report_notification() {
    local summary=$(build_report_summary)
    local err_count=${#REPORT_ERRORS[@]}
    local heal_count=${#REPORT_HEALED[@]}

    # Lokale Notification
    if [ "$REPORT_NOTIFY" = "local" ] || [ "$REPORT_NOTIFY" = "all" ]; then
        local subtitle=""
        [ $err_count -gt 0 ] && subtitle="${err_count} Fehler!"
        [ $heal_count -gt 0 ] && subtitle="${subtitle} ${heal_count} AI-Fixes"
        send_notification "Meister" "$summary" "$subtitle"
    fi

    # Pushover
    if [ "$REPORT_NOTIFY" = "pushover" ] || [ "$REPORT_NOTIFY" = "all" ]; then
        local priority=0
        [ $err_count -gt 0 ] && priority=1
        local detail="$summary"
        if [ $err_count -gt 0 ]; then
            detail="${detail}\nErrors: $(printf '%s, ' "${REPORT_ERRORS[@]}")"
        fi
        if [ $heal_count -gt 0 ]; then
            detail="${detail}\nHealed: $(printf '%s, ' "${REPORT_HEALED[@]}")"
        fi
        send_pushover "Meister Report" "$detail" "$priority"
    fi
}

#############################
# 10. LAUNCHAGENT (Fix #30)
#############################

install_launchagent() {
    local script_path=$(cd "$(dirname "$0")" && pwd)/$(basename "$0")
    local plist_path="$HOME/Library/LaunchAgents/com.meister.maintenance.plist"
    local label="com.meister.maintenance"

    # Schedule bestimmen
    local interval_secs=604800  # default: weekly
    local calendar_day=""
    case "$LAUNCHAGENT_SCHEDULE" in
        daily)   interval_secs=86400 ;;
        weekly)  interval_secs=604800 ;;
        monthly) calendar_day="<key>Day</key><integer>1</integer>" ;;
    esac

    log INFO "Installiere LaunchAgent ($LAUNCHAGENT_SCHEDULE)..."
    log STEP "   Script: $script_path"
    log STEP "   Plist:  $plist_path"

    # Bestehenden Agent stoppen
    if launchctl list 2>/dev/null | grep -q "$label"; then
        launchctl unload "$plist_path" 2>/dev/null
        log STEP "   Bestehender Agent gestoppt"
    fi

    mkdir -p "$HOME/Library/LaunchAgents"

    if [ "$LAUNCHAGENT_SCHEDULE" = "monthly" ]; then
        cat > "$plist_path" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${label}</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>${script_path}</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Day</key>
        <integer>1</integer>
        <key>Hour</key>
        <integer>10</integer>
        <key>Minute</key>
        <integer>0</integer>
    </dict>
    <key>StandardOutPath</key>
    <string>${MEISTER_DIR}/launchagent.log</string>
    <key>StandardErrorPath</key>
    <string>${MEISTER_DIR}/launchagent_err.log</string>
    <key>RunAtLoad</key>
    <false/>
</dict>
</plist>
PLISTEOF
    else
        cat > "$plist_path" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${label}</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>${script_path}</string>
    </array>
    <key>StartInterval</key>
    <integer>${interval_secs}</integer>
    <key>StandardOutPath</key>
    <string>${MEISTER_DIR}/launchagent.log</string>
    <key>StandardErrorPath</key>
    <string>${MEISTER_DIR}/launchagent_err.log</string>
    <key>RunAtLoad</key>
    <false/>
</dict>
</plist>
PLISTEOF
    fi

    launchctl load "$plist_path" 2>/dev/null
    if launchctl list 2>/dev/null | grep -q "$label"; then
        log FIX "LaunchAgent installiert und geladen"
        log INFO "   Schedule: $LAUNCHAGENT_SCHEDULE"
        log INFO "   Deinstallieren: launchctl unload $plist_path && rm $plist_path"
        echo ""
        echo -e "${GREEN}LaunchAgent erfolgreich installiert!${NC}"
        echo -e "  Schedule:      $LAUNCHAGENT_SCHEDULE"
        echo -e "  Plist:         $plist_path"
        echo -e "  Log:           $MEISTER_DIR/launchagent.log"
        echo -e "  Deinstallieren: launchctl unload $plist_path"
    else
        log ERROR "LaunchAgent konnte nicht geladen werden"
        echo -e "${RED}LaunchAgent Installation fehlgeschlagen!${NC}"
    fi
}

# ── Args (Fix #37: -a fuer alle Module) ──
while getopts ":aAXMTSCLOhcHnI" opt; do
  case $opt in
    a) RUN_CLAMAV=true; CLEAN_XCODE=true; RUN_MONOLINGUAL=true; EMPTY_TRASH=true
       RUN_SUDO_TASKS=true; CLEAN_CACHES=true; LIST_LARGE_FILES=true; NEEDS_SUDO=true ;;
    A) RUN_CLAMAV=true; NEEDS_SUDO=true ;;
    X) CLEAN_XCODE=true ;;
    M) RUN_MONOLINGUAL=true ;;
    T) EMPTY_TRASH=true ;;
    S) RUN_SUDO_TASKS=true; NEEDS_SUDO=true ;;
    C) CLEAN_CACHES=true; NEEDS_SUDO=true ;;
    L) LIST_LARGE_FILES=true ;;
    O) RUN_LMSTUDIO_COPY=true ;;
    c) CLAMAV_ONLY=true; RUN_CLAMAV=true; NEEDS_SUDO=true ;;
    H) SHOW_HEALTH=true ;;
    n) DRY_RUN=true ;;
    I) INSTALL_LAUNCHAGENT=true ;;
    h) echo "Usage: $(basename "$0") [-a] [-A] [-X] [-M] [-T] [-S] [-C] [-L] [-O] [-c] [-H] [-n] [-I]"
       echo "  -a  Alle optionalen Module (= -A -X -M -T -S -C -L)"
       echo "  -n  Dry-Run (zeigt was passieren wuerde, aendert nichts)"
       echo "  -I  LaunchAgent installieren (Schedule via Config: daily/weekly/monthly)"
       exit 0 ;;
    \?) log ERROR "Unbekannte Option: -$OPTARG"; exit 1 ;;
  esac
done

# ── START ──
rotate_logs
acquire_lock

echo -e "${BOLD}${BLUE}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║        MEISTER v11.0                     ║"
echo "  ║   macOS Maintenance & Self-Healing       ║"
$DRY_RUN && echo "  ║   [DRY-RUN MODUS]                        ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"

log INFO "Meister v11.0 gestartet ($(date))"
$DRY_RUN && log WARN "DRY-RUN: Keine Aenderungen werden vorgenommen"
log STEP "   Logfile: $LOGFILE"
[ -f "$MEISTER_CONFIG" ] && log STEP "   Config: $MEISTER_CONFIG geladen"
log STEP "   Flags: CLAMAV=$RUN_CLAMAV XCODE=$CLEAN_XCODE MONO=$RUN_MONOLINGUAL TRASH=$EMPTY_TRASH SUDO=$RUN_SUDO_TASKS CACHE=$CLEAN_CACHES LARGE=$LIST_LARGE_FILES LMS=$RUN_LMSTUDIO_COPY DRY=$DRY_RUN NOTIFY=$REPORT_NOTIFY"

# Fix #41: Zentraler Ollama-Starter + Fix #45: Modell-Check
if ollama_available || ensure_ollama_running ""; then
    log INFO "Ollama: online (${OLLAMA_MODEL})"
    local_models=$(ollama list 2>/dev/null | awk 'NR>1 {print $1}' | tr '\n' ', ')
    log STEP "   Modelle: ${local_models:-keine}"
    # Fix #45: Pruefen ob konfiguriertes Modell verfuegbar ist
    ensure_ollama_model
else
    log WARN "Ollama: nicht verfuegbar - kein AI-Heal"
    OLLAMA_ENABLED=false
fi

if $SHOW_HEALTH; then health_dashboard; release_lock; exit 0; fi
if $INSTALL_LAUNCHAGENT; then install_launchagent; release_lock; exit 0; fi

# Sudo immer anfordern (brew cask, migration, etc. brauchen es)
if ! $DRY_RUN; then
    log INFO "Requesting Sudo (brew cask + migration brauchen root)..."
    if sudo -v; then
        keep_sudo
        log INFO "   Sudo OK"
    else
        log WARN "Sudo verweigert - einige Operationen koennten fehlschlagen"
        report_add WARN "Sudo nicht verfuegbar"
    fi
fi

# Modul-Anzahl berechnen
if $CLAMAV_ONLY; then
    MODULE_TOTAL=2
else
    MODULE_TOTAL=9
    $RUN_CLAMAV && MODULE_TOTAL=$((MODULE_TOTAL + 1))
    $RUN_SUDO_TASKS && MODULE_TOTAL=$((MODULE_TOTAL + 1))
fi

# Preflight
section_header "Self-Healing Preflight"
module_timer_start
selfheal_preflight
module_timer_stop "Preflight"

if check_net; then
    if $CLAMAV_ONLY; then
        run_module_safe "ClamAV" module_clamav
    else
        run_module_safe "Homebrew"       module_homebrew
        run_module_safe "App Migration"  module_migration
        run_module_safe "App Store"      module_mas
        run_module_safe "MS Office"      module_office
        run_module_safe "Ollama Models"  module_ollama
        run_module_safe "macOS System"   module_system
        run_module_safe "Cleanup"        module_cleanup

        $RUN_CLAMAV && run_module_safe "ClamAV" module_clamav

        if $RUN_SUDO_TASKS; then
            section_header "System Maintenance (sudo)"
            module_timer_start
            log INFO "Starte periodic scripts..."
            log STEP "   periodic daily..."
            run_or_dry sudo periodic daily
            log STEP "   periodic weekly..."
            run_or_dry sudo periodic weekly
            log STEP "   periodic monthly..."
            run_or_dry sudo periodic monthly
            log INFO "   DNS-Cache flush..."
            run_or_dry sudo dscacheutil -flushcache
            report_add FIX "Ran periodic scripts & DNS flush"
            module_timer_stop "System Maintenance"
        fi
    fi
else
    log ERROR "Abbruch: Kein Internet"
fi

log_analysis
ollama_summary
print_report
save_history
send_report_notification
release_lock

# Fix #38: Exit-Code 1 bei Errors
[ ${#REPORT_ERRORS[@]} -gt 0 ] && exit 1
exit 0
